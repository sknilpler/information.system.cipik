-- MySQL dump 10.13  Distrib 5.7.32, for Linux (x86_64)
--
-- Host: localhost    Database: cipik
-- ------------------------------------------------------
-- Server version	5.7.32-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `centr`
--

DROP TABLE IF EXISTS `centr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `centr` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `short_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centr`
--

LOCK TABLES `centr` WRITE;
/*!40000 ALTER TABLE `centr` DISABLE KEYS */;
INSERT INTO `centr` VALUES (1,'Центр испытаний и применений измерительного комплекса','ЦИП ИК');
/*!40000 ALTER TABLE `centr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dorabotki`
--

DROP TABLE IF EXISTS `dorabotki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dorabotki` (
  `id` bigint(20) NOT NULL,
  `data_kon` date DEFAULT NULL,
  `data_nach` date DEFAULT NULL,
  `ispolnitel` varchar(255) DEFAULT NULL,
  `naimen` varchar(255) DEFAULT NULL,
  `osnovanie` varchar(255) DEFAULT NULL,
  `stanciya_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt4dbfxr3y6omknv0q28nl1do5` (`stanciya_id`),
  CONSTRAINT `FKt4dbfxr3y6omknv0q28nl1do5` FOREIGN KEY (`stanciya_id`) REFERENCES `stanciya` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dorabotki`
--

LOCK TABLES `dorabotki` WRITE;
/*!40000 ALTER TABLE `dorabotki` DISABLE KEYS */;
/*!40000 ALTER TABLE `dorabotki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drag_metal`
--

DROP TABLE IF EXISTS `drag_metal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drag_metal` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `number` double NOT NULL,
  `stanciya_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKo28w3dhaornkkg8mp0cpxgtgw` (`stanciya_id`),
  CONSTRAINT `FKo28w3dhaornkkg8mp0cpxgtgw` FOREIGN KEY (`stanciya_id`) REFERENCES `stanciya` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drag_metal`
--

LOCK TABLES `drag_metal` WRITE;
/*!40000 ALTER TABLE `drag_metal` DISABLE KEYS */;
/*!40000 ALTER TABLE `drag_metal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `id` bigint(20) NOT NULL,
  `addres` varchar(255) DEFAULT NULL,
  `birthday_date` datetime(6) DEFAULT NULL,
  `clothing_size` varchar(255) DEFAULT NULL,
  `data_start_work` datetime(6) DEFAULT NULL,
  `end_work` datetime(6) DEFAULT NULL,
  `gas_mask_size` varchar(255) DEFAULT NULL,
  `glove_size` varchar(255) DEFAULT NULL,
  `headgear_size` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `mittens_size` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `patronymic` varchar(255) DEFAULT NULL,
  `respirator_size` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `shoe_size` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `tab_nomer` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `komplex_id` bigint(20) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `otdel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgv3jh41brrpfxsn1rh228s96h` (`komplex_id`),
  KEY `FKcm3b9d5fiw8s6co7lkw8c0lbs` (`post_id`),
  KEY `FKcaugv0ayvbno6yf7x8qk42h27` (`otdel_id`),
  CONSTRAINT `FKcaugv0ayvbno6yf7x8qk42h27` FOREIGN KEY (`otdel_id`) REFERENCES `komplex` (`id`),
  CONSTRAINT `FKcm3b9d5fiw8s6co7lkw8c0lbs` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`),
  CONSTRAINT `FKgv3jh41brrpfxsn1rh228s96h` FOREIGN KEY (`komplex_id`) REFERENCES `komplex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (372,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Василий','Александрович',NULL,'Мужской',NULL,'Пинчук','372',NULL,6,33,NULL),(374,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Виктор','Николаевич',NULL,'Мужской',NULL,'Дианов','374',NULL,6,32,NULL),(375,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Руслан','Кудайбергенович',NULL,'Мужской',NULL,'Даулетов','375',NULL,6,36,NULL),(376,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Гулсим','Мажитовна',NULL,'Женский',NULL,'Иманбаева','376',NULL,6,15,NULL),(377,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Михаил','Юрьевич',NULL,'Мужской',NULL,'Капралов','377',NULL,6,36,NULL),(378,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Анна','Валерьевна',NULL,'Женский',NULL,'Костикова','378',NULL,6,36,NULL),(379,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Светлана','Ивановна',NULL,'Женский',NULL,'Кутяева','379',NULL,6,36,NULL),(380,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Игорь','Валентинович',NULL,'Мужской',NULL,'Ли','380',NULL,6,36,NULL),(381,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Айгуль','Адыльбаевна',NULL,'Женский',NULL,'Нурадинова','381',NULL,6,23,NULL),(382,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Лаура','Жанабергеновна',NULL,'Женский',NULL,'Нуржанова','382',NULL,6,23,NULL),(383,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Алексей','Арсентьевич',NULL,'Мужской',NULL,'Пецив','383',NULL,6,45,NULL),(384,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Кирилл','Максимович',NULL,'Мужской',NULL,'Свиридченко','384',NULL,6,45,NULL),(385,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Артём','Владимирович',NULL,'Мужской',NULL,'Тен','385',NULL,6,36,NULL),(386,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Анастасия','Романовна',NULL,'Женский',NULL,'Торшина','386',NULL,6,23,NULL),(387,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Андрей','Александрович',NULL,'Мужской',NULL,'Фуреев','387',NULL,6,36,NULL),(388,NULL,NULL,'60-62','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Варвара','Александровна',NULL,'Мужской',NULL,'Цёмкало','388',NULL,6,36,NULL),(389,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Канат','Маханович',NULL,'Мужской',NULL,'Айбасов','389',NULL,6,23,NULL),(390,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Сара','Нуратовна',NULL,'Женский',NULL,'Айбасова','390',NULL,6,48,NULL),(391,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Руслан','Рахимбекович',NULL,'Мужской',NULL,'Алтынбеков','391',NULL,6,36,NULL),(392,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Илья','Олегович',NULL,'Мужской',NULL,'Герасименко','392',NULL,6,43,NULL),(393,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Рустем','Кульмаханович',NULL,'Мужской',NULL,'Есекеев','393',NULL,6,42,NULL),(394,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Мырзабике','Абдуалиевна',NULL,'Женский',NULL,'Имангазиева','394',NULL,6,48,NULL),(395,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Адилжан','Мамайулы',NULL,'Мужской',NULL,'Мамай','395',NULL,6,38,NULL),(396,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Алексей','Валерьевич',NULL,'Мужской',NULL,'Огинцов','396',NULL,6,22,NULL),(397,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Валерий','Владимирович',NULL,'Мужской',NULL,'Пшиков','397',NULL,6,29,NULL),(398,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Бекзат','Жанабекович',NULL,'Мужской',NULL,'Сенгирбаев','398',NULL,6,51,NULL),(399,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Серик','Ескабылович',NULL,'Мужской',NULL,'Укшебаев','399',NULL,6,27,NULL),(400,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Андрей','Владимирович',NULL,'Мужской',NULL,'Щербаков','400',NULL,6,36,NULL),(401,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Илья','Витальевич',NULL,'Женский',NULL,'Щербина','401',NULL,6,36,NULL),(402,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Нурлан','Болатович',NULL,'Мужской',NULL,'Ешмаханов','402',NULL,6,23,NULL),(403,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Толкын','Ертугановна',NULL,'Женский',NULL,'Уристембаева','403',NULL,6,41,NULL),(404,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Алексей','Николаевич',NULL,'Мужской',NULL,'Белоцерковский','404',NULL,4,33,NULL),(406,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Игорь','Анатольевич',NULL,'Мужской',NULL,'Занин','406',NULL,4,31,NULL),(407,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Суханберди','Жубанышбаевич',NULL,'Мужской',NULL,'Исалдаев','407',NULL,4,36,NULL),(408,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Илья','Павлович',NULL,'Мужской',NULL,'Хорчин','408',NULL,4,23,NULL),(409,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Татьяна','Ивановна',NULL,'Женский',NULL,'Попова','409',NULL,4,45,NULL),(410,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Темирлан','Мирамбекович',NULL,'Мужской',NULL,'Жусупбаев','410',NULL,4,45,NULL),(411,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Ердос','Алтайулы',NULL,'Мужской',NULL,'Агисов','411',NULL,4,46,NULL),(412,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Наталья','Борисовна',NULL,'Мужской',NULL,'Ли','412',NULL,4,36,NULL),(413,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Дмитрий','Павлович',NULL,'Мужской',NULL,'Ли','413',NULL,4,15,NULL),(414,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Тимур','Берикович',NULL,'Мужской',NULL,'Муханов','414',NULL,4,23,NULL),(415,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Айгуль','Миндыгалиевна',NULL,'Женский',NULL,'Башарова','415',NULL,4,23,NULL),(416,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Рустам','Якудаевич',NULL,'Мужской',NULL,'Жантенов','416',NULL,4,45,NULL),(417,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Дамир','Мухаметович',NULL,'Мужской',NULL,'Рахимов','417',NULL,4,45,NULL),(418,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Елена','Константиновна',NULL,'Мужской',NULL,'Золокотская','418',NULL,4,36,NULL),(419,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','5-6',NULL,'Руслан','Александрович',NULL,'Мужской',NULL,'Шаркунов','419',NULL,4,23,NULL),(420,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Татьяна','Алексеевна',NULL,'Мужской',NULL,'Мардарь','420',NULL,4,22,NULL),(421,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Наталья','Борисовна',NULL,'Женский',NULL,'Дороднева','421',NULL,4,45,NULL),(422,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Юлия','Владимировна',NULL,'Женский',NULL,'Костина','422',NULL,4,46,NULL),(423,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Алексей','Валерьевич',NULL,'Мужской',NULL,'Гришин','423',NULL,4,31,NULL),(424,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Максим','Иванович',NULL,'Мужской',NULL,'Костров','424',NULL,4,29,NULL),(425,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Алексей','Яковлевич',NULL,'Мужской',NULL,'Пак','425',NULL,4,29,NULL),(426,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Федор','Алексеевич',NULL,'Мужской',NULL,'Дегтярев','426',NULL,4,36,NULL),(427,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Эмильбек','Алтынбекович',NULL,'Мужской',NULL,'Алтынбек','427',NULL,4,36,NULL),(428,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Вадим','Станиславович',NULL,'Мужской',NULL,'Краснощекий','428',NULL,4,16,NULL),(429,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Руслан','Жанбырбаевич',NULL,'Мужской',NULL,'Дуйсенбев','429',NULL,4,23,NULL),(430,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Чингисхан','Османович',NULL,'Мужской',NULL,'Айтбаев','430',NULL,4,23,NULL),(431,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Юрий','Владимирович',NULL,'Мужской',NULL,'Нестеров','431',NULL,4,23,NULL),(432,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Кайрат','Бекмырзаевич',NULL,'Мужской',NULL,'Сержанов','432',NULL,4,45,NULL),(433,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Софья','Зайнитдиновна',NULL,'Женский',NULL,'Тимофеева','433',NULL,4,36,NULL),(434,NULL,NULL,'68-70','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Алексей','Анатольевич',NULL,'Мужской',NULL,'Лебедев','434',NULL,4,36,NULL),(435,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Гульнур','Данаевна',NULL,'Женский',NULL,'Абдикаликова','435',NULL,4,23,NULL),(436,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Есен','Есетович',NULL,'Мужской',NULL,'Мырзагулов','436',NULL,4,23,NULL),(437,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Альбина','Ильичовна',NULL,'Женский',NULL,'Труфанова','437',NULL,4,23,NULL),(438,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Татьяна','Юрьевна',NULL,'Женский',NULL,'Никифорова','438',NULL,4,23,NULL),(439,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Алмас','Жумабаевич',NULL,'Мужской',NULL,'Елимбетов','439',NULL,4,36,NULL),(440,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Уразалы','Бакбергенович',NULL,'Мужской',NULL,'Утегенов','440',NULL,4,45,NULL),(441,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Наталья','Юрьевна',NULL,'Женский',NULL,'Купцова','441',NULL,4,45,NULL),(442,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Ирина','Дмитриевна',NULL,'Женский',NULL,'Зотова','442',NULL,4,45,NULL),(443,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Камбар','Карасаевич',NULL,'Мужской',NULL,'Тулегенов','443',NULL,4,45,NULL),(444,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Дарья','Николаевна',NULL,'Мужской',NULL,'Бахотская','444',NULL,4,45,NULL),(445,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Наталья','Михайловна',NULL,'Женский',NULL,'Федина','445',NULL,4,23,NULL),(446,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Ирина','Викторовна',NULL,'Мужской',NULL,'Левченко','446',NULL,4,23,NULL),(447,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Данагуль','Жанбырбаевна',NULL,'Женский',NULL,'Карибаева','447',NULL,4,23,NULL),(448,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Салтанат','Каскирбаевна',NULL,'Женский',NULL,'Есенбаева','448',NULL,4,23,NULL),(449,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Елена','Геннадьевна',NULL,'Мужской',NULL,'Войцеховская','449',NULL,4,23,NULL),(450,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Александра','Юрьевна',NULL,'Женский',NULL,'Бычкова','450',NULL,4,23,NULL),(451,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Зарина','Каскирбековна',NULL,'Женский',NULL,'Алдажанова','451',NULL,4,23,NULL),(452,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Сауле','Жаксылыковна',NULL,'Женский',NULL,'Мельникова','452',NULL,4,45,NULL),(453,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Людмила','Миннуловна',NULL,'Женский',NULL,'Турилова','453',NULL,4,45,NULL),(454,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Айнур','Журахатовна',NULL,'Женский',NULL,'Кутыбаева','454',NULL,4,45,NULL),(455,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','5-6',NULL,'Ерлан','Жауынбаевич',NULL,'Мужской',NULL,'Аймаханов','455',NULL,4,29,NULL),(456,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Рустем','Улукбекович',NULL,'Мужской',NULL,'Токбергенов','456',NULL,4,24,NULL),(457,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Мереке','Умиртаевич',NULL,'Мужской',NULL,'Несипбаев','457',NULL,4,41,NULL),(460,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Дархан','Азбергенович',NULL,'Мужской',NULL,'Бижанов','460',NULL,4,28,NULL),(461,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Жеткербай','Жанузакович',NULL,'Мужской',NULL,'Акмырзаев','461',NULL,4,40,NULL),(462,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Раш','Жалгасовна',NULL,'Женский',NULL,'Демисонова','462',NULL,4,47,NULL),(463,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Мархабат','Сериковна',NULL,'Женский',NULL,'Ерсейтова','463',NULL,4,47,NULL),(464,NULL,NULL,'64-66','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','7-8',NULL,'Михаил','Борисович',NULL,'Мужской',NULL,'Тряпицын','464',NULL,5,33,NULL),(466,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','5-6',NULL,'Талгат','Кадирович',NULL,'Мужской',NULL,'Оспанов','466',NULL,5,31,NULL),(467,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Вадим','Алексеевич',NULL,'Мужской',NULL,'Стрелин','467',NULL,5,31,NULL),(468,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Бахытжан','Бижанович',NULL,'Мужской',NULL,'Садыков','468',NULL,5,29,NULL),(469,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Вадим','Валерьевич',NULL,'Мужской',NULL,'Бауэр','469',NULL,5,36,NULL),(470,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Галя','Донесбаевна',NULL,'Женский',NULL,'Абишева','470',NULL,5,36,NULL),(471,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Анна','Сергеевна',NULL,'Женский',NULL,'Кузнецова','471',NULL,5,36,NULL),(472,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Елена','Айтжановна',NULL,'Мужской',NULL,'Деревянченко','472',NULL,5,36,NULL),(473,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Виктория','Андреевна',NULL,'Женский',NULL,'Дружинина','473',NULL,5,36,NULL),(474,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Юлия','Викторовна',NULL,'Мужской',NULL,'Журавель','474',NULL,5,36,NULL),(475,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Анна','Алексеевна',NULL,'Женский',NULL,'Лычёва','475',NULL,5,36,NULL),(476,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Диана','Владиславовна',NULL,'Мужской',NULL,'Ким','476',NULL,5,36,NULL),(477,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Айгуль','Умирзаковна',NULL,'Мужской',NULL,'Макогон','477',NULL,5,36,NULL),(478,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Наталья','Сергеевна',NULL,'Мужской',NULL,'Тен','478',NULL,5,36,NULL),(479,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','3-4',NULL,'Ольга','Вадимовна',NULL,'Женский',NULL,'Острецова','479',NULL,5,36,NULL),(480,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Зейнулла','Бихаликович',NULL,'Мужской',NULL,'Ниязбаев','480',NULL,5,36,NULL),(481,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Людмила','Кирилловна',NULL,'Женский',NULL,'Кархалева','481',NULL,5,36,NULL),(482,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Сабира','Алданышовна',NULL,'Женский',NULL,'Куптлеуова','482',NULL,5,15,NULL),(483,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Молдир','Бахытжановна',NULL,'Женский',NULL,'Садыкова','483',NULL,5,25,NULL),(484,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Карлыгаш','Айтбаевна',NULL,'Женский',NULL,'Айтбаева','484',NULL,5,25,NULL),(485,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Юлия','Сергеевна',NULL,'Женский',NULL,'Толмачева','485',NULL,5,23,NULL),(486,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Нургуль','Култаевна',NULL,'Женский',NULL,'Жусупбаева','486',NULL,5,23,NULL),(487,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Элмира','Бериковна',NULL,'Женский',NULL,'Асанова','487',NULL,5,23,NULL),(488,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Кункия','Аязбаевна',NULL,'Женский',NULL,'Мынбаева','488',NULL,5,23,NULL),(489,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Юлия','Владиславовна',NULL,'Мужской',NULL,'Заруцкая','489',NULL,5,23,NULL),(490,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Айгерим','Муратовна',NULL,'Женский',NULL,'Оспанова','490',NULL,5,23,NULL),(491,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Майра','Адайбековна',NULL,'Женский',NULL,'Ирюкова','491',NULL,5,23,NULL),(492,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Елена','Владимировна',NULL,'Женский',NULL,'Ключева','492',NULL,5,23,NULL),(493,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Елена','Сергеевна',NULL,'Мужской',NULL,'Маслий','493',NULL,5,23,NULL),(494,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Владлен','Ануарбекович',NULL,'Мужской',NULL,'Абдуллин','494',NULL,5,23,NULL),(495,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Жанар','Ертугановна',NULL,'Женский',NULL,'Алтынбекова','495',NULL,5,23,NULL),(496,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Максим','Васильевич',NULL,'Мужской',NULL,'Пинчук','496',NULL,5,23,NULL),(497,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Светлана','Валерьевна',NULL,'Женский',NULL,'Сидорина','497',NULL,5,45,NULL),(498,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Евгений','Александрович',NULL,'Мужской',NULL,'Заруцкий','498',NULL,5,45,NULL),(499,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Раиса','Николаевна',NULL,'Женский',NULL,'Толмачева','499',NULL,5,45,NULL),(500,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Айгуль','Абдикаликовна',NULL,'Женский',NULL,'Булекбаева','500',NULL,5,45,NULL),(501,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Наталья','Владимировна',NULL,'Женский',NULL,'Фёдорова','501',NULL,5,45,NULL),(502,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Семсер','Сейтагзимович',NULL,'Мужской',NULL,'Сартаев','502',NULL,5,24,NULL),(503,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Алик','Кенесбаевич',NULL,'Мужской',NULL,'Абишев','503',NULL,5,43,NULL),(504,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Аскар','Жаксылыкович',NULL,'Мужской',NULL,'Жубаниязов','504',NULL,5,52,NULL),(505,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Ануарбек','Айбатырович',NULL,'Мужской',NULL,'Искаков','505',NULL,5,28,NULL),(506,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Аскербек','Шанжарханович',NULL,'Мужской',NULL,'Курманаев','506',NULL,5,28,NULL),(507,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Октябрь','Абдикалиевич',NULL,'Мужской',NULL,'Жусупов','507',NULL,5,38,NULL),(508,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Татьяна','Валерьевна',NULL,'Женский',NULL,'Писнова','508',NULL,8,31,NULL),(509,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Сергей','Григорьевич',NULL,'Мужской',NULL,'Власов','509',NULL,8,34,NULL),(510,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Ирина','Александровна',NULL,'Женский',NULL,'Валяева','510',NULL,8,18,NULL),(511,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Александр','Николаевич',NULL,'Мужской',NULL,'Гужевников','511',NULL,8,18,NULL),(512,NULL,NULL,'54-56','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Сергей','Владимирович',NULL,'Мужской',NULL,'Бацунов','512',NULL,8,18,NULL),(513,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Андрей','Владимирович',NULL,'Мужской',NULL,'Берлизев','513',NULL,8,18,NULL),(514,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Андрей','Владимирович',NULL,'Мужской',NULL,'Цветков','514',NULL,8,18,NULL),(515,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Елена','Анатольевна',NULL,'Мужской',NULL,'Коваленко','515',NULL,8,15,NULL),(516,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Татьяна','Юрьевна',NULL,'Женский',NULL,'Никифорова','516',NULL,8,15,NULL),(517,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Янина','Станиславовна',NULL,'Мужской',NULL,'Казакевич','517',NULL,8,23,NULL),(518,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Владислав','Александрович',NULL,'Мужской',NULL,'Панченко','518',NULL,8,23,NULL),(519,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Светлана','Леонидовна',NULL,'Мужской',NULL,'Яроцкая','519',NULL,8,23,NULL),(520,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Олеся','Валерьевна',NULL,'Мужской',NULL,'Иващенко','520',NULL,8,19,NULL),(521,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'59','3-4',NULL,'Людмила','Борисовна',NULL,'Женский',NULL,'Кулешева','521',NULL,8,19,NULL),(522,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Елена','Васильевна',NULL,'Женский',NULL,'Прохорова','522',NULL,8,19,NULL),(523,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Ирина','Геннадьевна',NULL,'Женский',NULL,'Сорокина','523',NULL,8,19,NULL),(524,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Людмила','Анатольевна',NULL,'Женский',NULL,'Тафинцева','524',NULL,8,19,NULL),(525,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Андрей','Вячеславович',NULL,'Мужской',NULL,'Бирюков','525',NULL,3,18,NULL),(526,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Наталья','Михайловна',NULL,'Мужской',NULL,'Жуковская','526',NULL,3,23,NULL),(527,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Александр','Николаевич',NULL,'Мужской',NULL,'Матвиенко','527',NULL,3,31,NULL),(528,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Шолпан','Орынбаевна',NULL,'Женский',NULL,'Маханова','528',NULL,3,23,NULL),(529,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Александр','Федорович',NULL,'Мужской',NULL,'Могильников','529',NULL,3,23,NULL),(531,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Майра','Максимовна',NULL,'Женский','38','Табанова','531',NULL,3,18,NULL),(532,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Александр','Иванович',NULL,'Мужской',NULL,'Тимошенко','532',NULL,3,33,NULL),(533,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Наталья','Борисовна',NULL,'Мужской',NULL,'Музалевская','533',NULL,3,23,NULL),(534,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Светлана','Валерьевна',NULL,'Мужской',NULL,'Герасимчук','534',NULL,3,29,NULL),(535,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'62','3-4',NULL,'Виктор','Вячеславович',NULL,'Мужской',NULL,'Пак','535',NULL,3,18,NULL),(536,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Лариса','Сергеевна',NULL,'Мужской',NULL,'Шевчук','536',NULL,3,23,NULL),(537,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'59','3-4',NULL,'Александр','Александрович',NULL,'Мужской',NULL,'Тимошенко','537',NULL,3,29,NULL),(538,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Наталия','Юлиановна',NULL,'Женский',NULL,'Бирюкова','538',NULL,3,23,NULL),(539,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Максим','Михайлович',NULL,'Мужской',NULL,'Голованов','539',NULL,3,23,NULL),(540,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Алексей','Викторович',NULL,'Мужской','41','Бахан','540',NULL,3,15,NULL),(541,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Оксана','Анатольевна',NULL,'Женский',NULL,'Болотова','541',NULL,3,23,NULL),(542,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Анастасия','Евгеньевна',NULL,'Женский',NULL,'Занина','542',NULL,3,23,NULL),(543,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Ирина','Валентиновна',NULL,'Женский',NULL,'Витохина','543',NULL,3,23,NULL),(544,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Елена','Юрьевна',NULL,'Мужской',NULL,'Шаульская','544',NULL,3,23,NULL),(545,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Александр','Евгеньевич',NULL,'Мужской',NULL,'Гуржий','545',NULL,3,29,NULL),(546,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Сергей','Ананьевич',NULL,'Мужской',NULL,'Виноградчий','546',NULL,3,29,NULL),(547,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Алексей','Юрьевич',NULL,'Мужской',NULL,'Давыдов','547',NULL,3,29,NULL),(548,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Роман','Анатольевич',NULL,'Мужской',NULL,'Дойнов','548',NULL,3,23,NULL),(549,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Игорь','Семенович',NULL,'Мужской',NULL,'Ермаков','549',NULL,3,18,NULL),(550,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Наталья','Владимировна',NULL,'Мужской',NULL,'Ильенко','550',NULL,3,23,NULL),(551,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','5-6',NULL,'Артем','Николаевич',NULL,'Мужской',NULL,'Колодяжный','551',NULL,3,31,NULL),(552,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Ирина','Витальевна',NULL,'Женский',NULL,'Кузьмина','552',NULL,3,23,NULL),(553,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Александр','Сергеевич',NULL,'Мужской',NULL,'Петелин','553',NULL,3,16,NULL),(554,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Алексей','Юрьевич',NULL,'Мужской',NULL,'Светличный','554',NULL,3,29,NULL),(555,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Ольга','Витальевна',NULL,'Мужской',NULL,'Тимошенко','555',NULL,3,23,NULL),(556,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Виктория','Викторовна',NULL,'Женский',NULL,'Кудрякова','556',NULL,3,23,NULL),(557,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Мария','Темировна',NULL,'Женский',NULL,'Джантурина','557',NULL,3,44,NULL),(558,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Светлана','Сериковна',NULL,'Женский',NULL,'Ескабылова','558',NULL,3,47,NULL),(559,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Еркин','Кенжебаевич',NULL,'Мужской',NULL,'Жанбаев','559',NULL,3,49,NULL),(560,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Жанибек','Сабитович',NULL,'Мужской',NULL,'Жумагалиев','560',NULL,3,27,NULL),(561,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','5-6',NULL,'Бахытжан','Каржаубаевич',NULL,'Мужской',NULL,'Жумалиев','561',NULL,3,29,NULL),(562,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Жаксыбай','Абдразакович',NULL,'Мужской',NULL,'Изекеев','562',NULL,3,39,NULL),(563,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'59','1-2',NULL,'Гульмира','Жорабаевна',NULL,'Женский',NULL,'Канжигитова','563',NULL,3,24,NULL),(564,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Кенжебек','Сайнович',NULL,'Мужской',NULL,'Муратов','564',NULL,3,44,NULL),(565,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Ирина','Вадимовна',NULL,'Женский',NULL,'Маковеева','565',NULL,3,23,NULL),(566,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Артём','Андреевич',NULL,'Мужской',NULL,'Маханьков','566',NULL,3,23,NULL),(567,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Нурбол','Дастанович',NULL,'Мужской',NULL,'Алиев','567',NULL,3,23,NULL),(568,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Виктория','Владимировна',NULL,'Женский',NULL,'Уварова','568',NULL,3,23,NULL),(569,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','3-4',NULL,'Дмитрий','Сергеевич',NULL,'Мужской',NULL,'Бацунов','569',NULL,3,29,NULL),(570,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Ольга','Владимировна',NULL,'Женский',NULL,'Яковлева','570',NULL,3,23,NULL),(571,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Виктория','Олеговна',NULL,'Женский',NULL,'Хайрадимова','571',NULL,3,29,NULL),(572,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'52','3-4',NULL,'Елена','Владимировна',NULL,'Женский',NULL,'Кириллова','572',NULL,3,23,NULL),(573,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Куаныш','Орынбасарович',NULL,'Мужской',NULL,'Шегиров','573',NULL,3,53,NULL),(574,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'60','5-6',NULL,'Игорь','Олегович',NULL,'Мужской',NULL,'Хлыбов','574',NULL,3,45,NULL),(575,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Ольга','Николаевна',NULL,'Женский',NULL,'Кархалева','575',NULL,3,23,NULL),(576,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Людмила','Игоревна',NULL,'Мужской',NULL,'Тимошенко','576',NULL,3,23,NULL),(577,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Артём','Александрович',NULL,'Мужской',NULL,'Корчагин','577',NULL,3,23,NULL),(579,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Нина','Анатольевна',NULL,'Женский',NULL,'Просочкина','579',NULL,3,23,NULL),(580,NULL,NULL,'40-42','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Марина','Валерьевна',NULL,'Мужской',NULL,'Цай','580',NULL,3,23,NULL),(581,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Нурислам','Муратович',NULL,'Мужской',NULL,'Айкожаев','581',NULL,3,23,NULL),(582,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Игорь','Владимирович',NULL,'Мужской',NULL,'Самойленко','582',NULL,3,23,NULL),(583,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Елена','Витальевна',NULL,'Мужской',NULL,'Цай','583',NULL,3,23,NULL),(584,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'59','1-2',NULL,'Марсель','Бисеновна',NULL,'Женский',NULL,'Ахметова','584',NULL,3,47,NULL),(585,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Эльвира','Шариповна',NULL,'Мужской',NULL,'Божко','585',NULL,3,47,NULL),(586,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Татьяна','Павловна',NULL,'Мужской',NULL,'Золотых','586',NULL,3,47,NULL),(587,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Алеся','Сергеевна',NULL,'Женский',NULL,'Зотова','587',NULL,3,47,NULL),(588,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Каскирбай','Еснбаевич',NULL,'Мужской',NULL,'Аманбаев','588',NULL,11,31,NULL),(589,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Марат','Насырович',NULL,'Мужской',NULL,'Оразалиев','589',NULL,11,36,NULL),(590,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Александр','Семенович',NULL,'Мужской',NULL,'Линьков','590',NULL,11,18,NULL),(591,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Дмитрий','Владимирович',NULL,'Женский',NULL,'Ча','591',NULL,11,18,NULL),(594,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Регина','Рузалевна',NULL,'Женский',NULL,'Хайруллина','594',NULL,11,42,NULL),(596,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Женис','Анесович',NULL,'Мужской','45','Кожекеев','596',NULL,2,29,NULL),(597,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Бекболат','Ануарович',NULL,'Мужской',NULL,'Бекешов','597',NULL,2,23,NULL),(598,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Елена','Валерьевна',NULL,'Мужской',NULL,'Лесовицкая','598',NULL,2,16,NULL),(599,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Асель','Талгатовна',NULL,'Женский',NULL,'Жумалиева','599',NULL,2,42,NULL),(600,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Зейнеш','Дабыловна',NULL,'Женский',NULL,'Досанова','600',NULL,2,42,NULL),(601,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Татьяна','Борисовна',NULL,'Женский',NULL,'Алюсова','601',NULL,2,42,NULL),(602,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Нуржамал','Дабыловна',NULL,'Женский',NULL,'Жургентаева','602',NULL,2,41,NULL),(603,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Татьяна','Петровна',NULL,'Женский',NULL,'Линькова','603',NULL,2,46,NULL),(604,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Сергей','Валентинович',NULL,'Мужской',NULL,'Журавель','604',NULL,14,33,NULL),(605,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Андрей','Иванович',NULL,'Мужской',NULL,'Власов','605',NULL,14,18,NULL),(606,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Павел','Сергеевич',NULL,'Мужской',NULL,'Гирик','606',NULL,14,18,NULL),(607,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','5-6',NULL,'Инна','Валериевна',NULL,'Женский',NULL,'Калистратова','607',NULL,14,18,NULL),(608,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Анастасия','Ярославовна',NULL,'Мужской',NULL,'Прийдун','608',NULL,14,18,NULL),(609,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Сергей','Борисович',NULL,'Мужской',NULL,'Савелов','609',NULL,14,16,NULL),(610,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Николай','Викторович',NULL,'Мужской',NULL,'Кархалев','610',NULL,9,29,NULL),(611,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Татьяна','Васильевна',NULL,'Мужской',NULL,'Дорошкевич','611',NULL,9,18,NULL),(612,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Наталья','Егоровна',NULL,'Мужской',NULL,'Сысак','612',NULL,9,41,NULL),(613,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Тойгул','Алдаунгаровна',NULL,'Женский',NULL,'Естемесова','613',NULL,9,35,NULL),(614,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Нурбек','Бакбергенович',NULL,'Мужской',NULL,'Аддамжаров','614',NULL,9,26,NULL),(615,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Василий','Семенович',NULL,'Мужской',NULL,'Яковлев','615',NULL,12,37,NULL),(616,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'59','7-8',NULL,'Петр','Александрович',NULL,'Мужской',NULL,'Богданов','616',NULL,12,21,NULL),(617,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'59','5-6',NULL,'Александр','Константинович',NULL,'Мужской',NULL,'Бекеев','617',NULL,12,17,NULL),(618,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Максим','Валерьевич',NULL,'Мужской',NULL,'Герасимчук','618',NULL,7,33,NULL),(620,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Арыстан','Мирамбекович',NULL,'Мужской',NULL,'Жусупбаев','620',NULL,7,29,NULL),(621,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Берик','Жамантаевич',NULL,'Мужской',NULL,'Абжанов','621',NULL,7,28,NULL),(622,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Махан','Сатыбаевич',NULL,'Мужской',NULL,'Айбасов','622',NULL,7,52,NULL),(623,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Болат','Жумабаевич',NULL,'Мужской',NULL,'Исапов','623',NULL,7,52,NULL),(624,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Казыбек','Раушанович',NULL,'Мужской',NULL,'Дербисбеков','624',NULL,7,39,NULL),(625,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Берик','Танирбергенович',NULL,'Мужской',NULL,'Байжанов','625',NULL,7,38,NULL),(627,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Алибек','Багдаулетович',NULL,'Мужской',NULL,'Сагадинов','627',NULL,7,44,NULL),(629,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Гульмира','Суханбергеновна',NULL,'Женский',NULL,'Сейтмамбетова','629',NULL,7,47,NULL),(630,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','3-4',NULL,'Менсулу','Шукуровна',NULL,'Женский',NULL,'Успанова','630',NULL,7,47,NULL),(633,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Александр','Викторович',NULL,'Мужской',NULL,'Макушев','633',NULL,7,31,NULL),(634,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Нурдаулет','Кужабекович',NULL,'Мужской',NULL,'Матабаев','634',NULL,7,36,NULL),(635,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','1-2',NULL,'Талгат','Болатбекович',NULL,'Мужской',NULL,'Кадыров','635',NULL,7,36,NULL),(636,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Раушан','Рахатовна',NULL,'Женский',NULL,'Кутыбаева','636',NULL,7,23,NULL),(638,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Айгерим','Нуртугановна',NULL,'Женский',NULL,'Досниязова','638',NULL,7,23,NULL),(639,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Эльвира','Анасовна',NULL,'Женский',NULL,'Юсупова','639',NULL,7,23,NULL),(640,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Сериккуль','Асановна',NULL,'Женский',NULL,'Исабаева','640',NULL,7,45,NULL),(641,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','3-4',NULL,'Валентина','Владимировна',NULL,'Женский',NULL,'Шестакова','641',NULL,7,45,NULL),(642,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Салтанат','Аманжоловна',NULL,'Женский',NULL,'Рустембаева','642',NULL,7,45,NULL),(643,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Айнур','Кайыргалиевна',NULL,'Мужской',NULL,'Кайыргали','643',NULL,7,45,NULL),(644,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Жулдызай','Бакбергеновна',NULL,'Женский',NULL,'Бекмагамбетова','644',NULL,7,45,NULL),(645,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','3-4',NULL,'Айнур','Тайбековна',NULL,'Женский',NULL,'Ауесбаева','645',NULL,7,46,NULL),(646,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Рамиль','Равильевич',NULL,'Мужской',NULL,'Зарипов','646',NULL,7,31,NULL),(647,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Юрий','Анатольевич',NULL,'Мужской',NULL,'Вохманцев','647',NULL,7,30,NULL),(648,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Федор','Сергеевич',NULL,'Мужской',NULL,'Носов','648',NULL,7,36,NULL),(651,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Николай','Иванович',NULL,'Мужской',NULL,'Воробьев','651',NULL,7,36,NULL),(652,NULL,NULL,'56-58','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Артур','Изтурганович',NULL,'Мужской',NULL,'Кушимов','652',NULL,7,15,NULL),(653,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','1-2',NULL,'Гульфия','Жардемовна',NULL,'Женский',NULL,'Баймухамбетова','653',NULL,7,15,NULL),(667,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Алексей','Васильевич',NULL,'Мужской',NULL,'Садов','667',NULL,7,31,NULL),(668,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','1-2',NULL,'Наталья','Евгеньевна',NULL,'Женский',NULL,'Рябушкина','668',NULL,7,36,NULL),(669,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Мейримжан','Елубаевич',NULL,'Мужской',NULL,'Есиркепов','669',NULL,7,15,NULL),(671,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Ирина','Владимировна',NULL,'Мужской',NULL,'Шнейдер','671',NULL,7,23,NULL),(672,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Галия','Жолдасовна',NULL,'Женский',NULL,'Жанабаева','672',NULL,7,23,NULL),(673,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Айсулу','Кемаладиновна',NULL,'Женский',NULL,'Зейнуллина','673',NULL,7,23,NULL),(674,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Оксана','Валериевна',NULL,'Мужской',NULL,'Цай','674',NULL,7,23,NULL),(675,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'54','1-2',NULL,'Атир','Толепбергеновна',NULL,'Женский',NULL,'Касимова','675',NULL,7,23,NULL),(676,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Алексей','Павлович',NULL,'Мужской',NULL,'Кузьмин','676',NULL,7,31,NULL),(677,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Сагидула','Гайнулович',NULL,'Мужской',NULL,'Кызылбасов','677',NULL,7,36,NULL),(678,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Райхан','Рахатовна',NULL,'Женский',NULL,'Кутыбаева','678',NULL,7,36,NULL),(680,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','3-4',NULL,'Диас','Каниевич',NULL,'Мужской',NULL,'Арымбеков','680',NULL,7,15,NULL),(681,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'58','5-6',NULL,'Сергей','Иосифович',NULL,'Мужской',NULL,'Зелинский','681',NULL,7,23,NULL),(682,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Гульназия','Канитуреевна',NULL,'Женский',NULL,'Алдамжарова','682',NULL,7,23,NULL),(683,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','5-6',NULL,'Жаркынай','Бакбергеновна',NULL,'Женский',NULL,'Алишева','683',NULL,7,22,NULL),(684,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'55','1-2',NULL,'Айдана','Асылбековна',NULL,'Женский',NULL,'Сакыбекова','684',NULL,7,23,NULL),(685,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'57','3-4',NULL,'Екатерина','Сергеевна',NULL,'Мужской',NULL,'Дубовик','685',NULL,7,23,NULL),(686,NULL,NULL,'48-50','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Елена','Николаевна',NULL,'Женский',NULL,'Полюбина','686',NULL,13,18,NULL),(687,NULL,NULL,'44-46','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Ольга','Ивановна',NULL,'Женский',NULL,'Буланчикова','687',NULL,10,16,NULL),(688,NULL,NULL,'52-54','2021-04-27 00:00:00.000000',NULL,NULL,NULL,'56','3-4',NULL,'Наталья','Васильевна',NULL,'Женский',NULL,'Щербина','688',NULL,13,42,NULL),(1043,NULL,NULL,'52-54','2021-06-08 11:46:45.583000',NULL,NULL,NULL,'56','3-4',NULL,'Иван','Иванович',NULL,'Мужской','45','Иванов','462462456',NULL,3,22,NULL);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (1054);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `individual_protection_means`
--

DROP TABLE IF EXISTS `individual_protection_means`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `individual_protection_means` (
  `id` bigint(20) NOT NULL,
  `ed_izm` varchar(255) DEFAULT NULL,
  `namesiz` varchar(255) DEFAULT NULL,
  `typeipm` varchar(255) DEFAULT NULL,
  `nomenclature_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `individual_protection_means`
--

LOCK TABLES `individual_protection_means` WRITE;
/*!40000 ALTER TABLE `individual_protection_means` DISABLE KEYS */;
INSERT INTO `individual_protection_means` VALUES (690,'к-т','Костюм для защиты от общих производственных загрязнений и механических воздействий','Одежда',NULL),(692,'шт','Халат для защиты от общих производственных загрязнений и механических воздействий','Одежда',NULL),(693,'пара','Перчатки с точечным покрытием','Перчатки',NULL),(694,'пара','Сапоги резиновые с защитным подноском','Обувь',NULL),(695,'шт','Очки защитные','Головной убор',NULL),(696,'пара','Боты или галоши диэлектрические','Обувь',NULL),(697,'пара','Перчатки диэлектрические','Перчатки',NULL);
/*!40000 ALTER TABLE `individual_protection_means` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipmstandard`
--

DROP TABLE IF EXISTS `ipmstandard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipmstandard` (
  `id` bigint(20) NOT NULL,
  `issuance_rate` int(11) NOT NULL,
  `regulatory_documents` varchar(255) DEFAULT NULL,
  `service_life` int(11) NOT NULL,
  `individual_protection_means_id` bigint(20) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK74n18l3x4993igdo9h53302ct` (`individual_protection_means_id`),
  KEY `FKbn90fjahh5xmjn8wlw0qp85hl` (`post_id`),
  CONSTRAINT `FK74n18l3x4993igdo9h53302ct` FOREIGN KEY (`individual_protection_means_id`) REFERENCES `individual_protection_means` (`id`),
  CONSTRAINT `FKbn90fjahh5xmjn8wlw0qp85hl` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipmstandard`
--

LOCK TABLES `ipmstandard` WRITE;
/*!40000 ALTER TABLE `ipmstandard` DISABLE KEYS */;
INSERT INTO `ipmstandard` VALUES (698,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,15),(699,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,692,15),(700,4,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,693,15),(701,1,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,694,15),(702,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,16),(703,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,692,16),(704,4,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,693,16),(705,1,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,694,16),(706,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,17),(707,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,18),(708,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,19),(709,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,20),(710,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,21),(711,1,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,22),(712,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,692,22),(713,4,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,693,22),(714,1,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,694,22),(715,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,23),(716,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,692,23),(717,4,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,693,23),(718,1,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,694,23),(719,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,696,51),(720,4,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,697,51),(721,2,'Приказ Министерства труда России от 9 декабря 2014 г.  № 997н  п. 23',12,690,51);
/*!40000 ALTER TABLE `ipmstandard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issuedsiz`
--

DROP TABLE IF EXISTS `issuedsiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issuedsiz` (
  `id` bigint(20) NOT NULL,
  `date_end_wear` datetime(6) DEFAULT NULL,
  `date_issued` datetime(6) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `write_off_act` varchar(255) DEFAULT NULL,
  `employee_id` bigint(20) DEFAULT NULL,
  `siz_id` bigint(20) DEFAULT NULL,
  `komplex_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9ox5apgqxtmowlib1hjlf407s` (`employee_id`),
  KEY `FK45h4d5xfqm6jhg65s5oyvhcs` (`siz_id`),
  KEY `FKefucnfyofs1n0imeyf88hgmey` (`komplex_id`),
  CONSTRAINT `FK45h4d5xfqm6jhg65s5oyvhcs` FOREIGN KEY (`siz_id`) REFERENCES `individual_protection_means` (`id`),
  CONSTRAINT `FK9ox5apgqxtmowlib1hjlf407s` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `FKefucnfyofs1n0imeyf88hgmey` FOREIGN KEY (`komplex_id`) REFERENCES `komplex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issuedsiz`
--

LOCK TABLES `issuedsiz` WRITE;
/*!40000 ALTER TABLE `issuedsiz` DISABLE KEYS */;
INSERT INTO `issuedsiz` VALUES (722,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,490,690,NULL),(723,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,490,690,NULL),(724,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,556,690,NULL),(725,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,556,690,NULL),(726,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,568,690,NULL),(727,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,568,690,NULL),(728,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,580,690,NULL),(729,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','1-2','40-42','Выдано',NULL,580,690,NULL),(731,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(732,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(733,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(734,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(735,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(736,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(737,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(738,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(739,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(740,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(741,NULL,NULL,'1-2','40-42','На складе',NULL,NULL,690,3),(742,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(743,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(744,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(745,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(746,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(747,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(748,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(749,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(750,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(751,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(752,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(753,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(754,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(755,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(756,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(757,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(758,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(759,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(760,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(761,NULL,NULL,'1-2','42-44','На складе',NULL,NULL,690,NULL),(772,'2022-04-27 09:54:13.352000','2021-04-27 09:54:13.352000','3-4','44-46','Выдано',NULL,687,690,NULL),(773,'2022-04-27 09:54:13.352000','2021-04-27 09:54:13.352000','3-4','44-46','Выдано',NULL,687,690,NULL),(774,'2022-04-27 10:15:35.611000','2021-04-27 10:15:35.611000','3-4','44-46','Выдано',NULL,522,690,NULL),(775,'2022-04-27 10:15:35.611000','2021-04-27 10:15:35.611000','3-4','44-46','Выдано',NULL,522,690,NULL),(776,'2022-04-27 10:16:02.960000','2021-04-27 10:16:02.960000','3-4','44-46','Выдано',NULL,396,690,NULL),(777,'2022-04-27 10:16:02.960000','2021-04-27 10:16:02.960000','3-4','44-46','Выдано',NULL,396,690,NULL),(778,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','3-4','44-46','Списано','Акт списания №395 от 04.05.2021г',381,690,NULL),(779,'2022-06-02 10:09:38.164000','2021-06-02 10:09:38.164000','3-4','44-46','Выдано',NULL,381,690,NULL),(780,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','3-4','44-46','Выдано',NULL,446,690,NULL),(781,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','3-4','44-46','Выдано',NULL,446,690,NULL),(782,'2022-06-02 10:09:38.164000','2021-06-02 10:09:38.164000','3-4','44-46','Выдано',NULL,381,690,NULL),(783,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(784,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(785,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(786,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(787,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(788,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(789,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(790,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(791,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(792,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(793,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(794,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(795,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(796,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(797,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(798,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(799,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(800,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(801,NULL,NULL,'3-4','46-48','На складе',NULL,NULL,690,NULL),(802,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(803,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(804,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(805,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(806,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(807,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(808,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(809,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(810,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(811,NULL,NULL,'5-6','44-46','На складе',NULL,NULL,690,NULL),(822,'2022-04-27 09:54:13.352000','2021-04-27 09:54:13.352000','5-6','48-50','Выдано',NULL,553,690,NULL),(823,'2022-04-27 09:54:13.352000','2021-04-27 09:54:13.352000','5-6','48-50','Выдано',NULL,553,690,NULL),(824,'2022-04-27 09:55:14.134000','2021-04-27 09:55:14.134000','5-6','48-50','Выдано',NULL,607,690,NULL),(825,'2022-04-27 09:55:14.134000','2021-04-27 09:55:14.134000','5-6','48-50','Выдано',NULL,607,690,NULL),(826,'2022-05-05 06:31:12.896000','2021-05-05 06:31:12.896000','5-6','48-50','Выдано',NULL,683,690,NULL),(827,'2022-05-05 06:31:12.896000','2021-05-05 06:31:12.896000','5-6','48-50','Выдано',NULL,683,690,NULL),(828,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','5-6','48-50','Выдано',NULL,429,690,NULL),(829,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','5-6','48-50','Выдано',NULL,429,690,NULL),(830,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','5-6','48-50','Выдано',NULL,430,690,NULL),(831,'2022-05-04 06:52:43.329000','2021-05-04 06:52:43.329000','5-6','48-50','Выдано',NULL,430,690,NULL),(979,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(980,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(981,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(982,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(983,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(984,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(985,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(986,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(987,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(988,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(989,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(990,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(991,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(992,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(993,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(994,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(995,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(996,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(997,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(998,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(999,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1000,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1001,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1002,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1003,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1004,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1005,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1006,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1007,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1008,NULL,NULL,'','44','На складе',NULL,NULL,694,NULL),(1009,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1010,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1011,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1012,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1013,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1014,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1015,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1016,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1017,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1018,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1019,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1020,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1021,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1022,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1023,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1024,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1025,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1026,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1027,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1028,NULL,NULL,'3-4','42-44','На складе',NULL,NULL,690,NULL),(1029,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1030,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1031,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1032,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1033,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1034,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1035,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1036,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1037,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1038,NULL,NULL,'7-8','60-62','На складе',NULL,NULL,690,NULL),(1044,'2022-06-08 11:54:21.291000','2021-06-08 11:54:21.291000','3-4','52-54','Списано','Акт № 239 от 08.06.2021г.',1043,690,NULL),(1045,'2023-02-16 19:00:00.000000','2021-06-08 11:55:04.677000','3-4','52-54','Выдано',NULL,1043,690,NULL),(1046,'2022-06-08 11:59:09.766000','2021-06-08 11:59:09.766000','3-4','52-54','Выдано',NULL,536,690,NULL),(1047,'2022-06-08 11:59:09.766000','2021-06-08 11:59:09.766000','3-4','52-54','Выдано',NULL,536,690,NULL),(1048,'2022-06-08 11:59:09.766000','2021-06-08 11:59:09.766000','3-4','52-54','Выдано',NULL,541,690,NULL),(1049,'2022-06-08 11:59:09.766000','2021-06-08 11:59:09.766000','3-4','52-54','Выдано',NULL,541,690,NULL),(1050,NULL,NULL,'3-4','52-54','На складе',NULL,NULL,690,NULL),(1051,NULL,NULL,'3-4','52-54','На складе',NULL,NULL,690,NULL),(1052,NULL,NULL,'3-4','52-54','На складе',NULL,NULL,690,NULL),(1053,NULL,NULL,'3-4','52-54','На складе',NULL,NULL,690,NULL);
/*!40000 ALTER TABLE `issuedsiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `all_count` int(11) NOT NULL,
  `bill` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `count` int(11) NOT NULL,
  `date_of_receive` date DEFAULT NULL,
  `dlc_count` int(11) NOT NULL,
  `expense_item` varchar(255) DEFAULT NULL,
  `issued` bit(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komplex`
--

DROP TABLE IF EXISTS `komplex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komplex` (
  `id` bigint(20) NOT NULL,
  `adres` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `short_name` varchar(255) DEFAULT NULL,
  `centr_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKc7bcvoixcxug2jj7xyecgsbgw` (`centr_id`),
  KEY `FKqjn704geuc8jpr1p0drg957v8` (`role_id`),
  CONSTRAINT `FKc7bcvoixcxug2jj7xyecgsbgw` FOREIGN KEY (`centr_id`) REFERENCES `centr` (`id`),
  CONSTRAINT `FKqjn704geuc8jpr1p0drg957v8` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komplex`
--

LOCK TABLES `komplex` WRITE;
/*!40000 ALTER TABLE `komplex` DISABLE KEYS */;
INSERT INTO `komplex` VALUES (2,'Ул. Титова, 7','Группа эксплуатации','ГЭ',1,3),(3,'Ул. Титова, 7','Информационно-вычислительный центр','ИВЦ',1,4),(4,'пл. 18','Измерительный пункт №1','ИП-1',1,5),(5,'пл. 44','Измерительный пункт №2','ИП-2',1,6),(6,'пл. 97','Измерительный пункт №3','ИП-3',1,7),(7,'пл. 23','Измерительный пункт №5','ИП-5',1,8),(8,'Ул. Титова, 7','Комплексный отдел испытаний и применения средств измерительного комплекса','КОИПСИК',1,9),(9,'Ул. Титова, 7','Материально-техническое обеспечение','МТО',1,10),(10,'Ул. Титова, 7','Охрана труда','ОТ',1,11),(11,'Ул. Титова, 7','Хозяйственный отдел','ОХСОиЭЗС',1,12),(12,'Ул. Титова, 7','Управление','Управление',1,13),(13,'Ул. Титова, 7','Учебный центр','УЦ',1,14),(14,'Ул. Титова, 7','Электромагнитной совместимости','ЭМС',1,15);
/*!40000 ALTER TABLE `komplex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `norma`
--

DROP TABLE IF EXISTS `norma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `norma` (
  `id` bigint(20) NOT NULL,
  `number` double NOT NULL,
  `rashodniki_id` bigint(20) DEFAULT NULL,
  `sredstvo_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5v8s0mq9d6noe7ij54hotvko6` (`rashodniki_id`),
  KEY `FKrndi6msw99oqu8skm0io0n5nh` (`sredstvo_id`),
  CONSTRAINT `FK5v8s0mq9d6noe7ij54hotvko6` FOREIGN KEY (`rashodniki_id`) REFERENCES `rashodniki` (`id`),
  CONSTRAINT `FKrndi6msw99oqu8skm0io0n5nh` FOREIGN KEY (`sredstvo_id`) REFERENCES `sredstvo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `norma`
--

LOCK TABLES `norma` WRITE;
/*!40000 ALTER TABLE `norma` DISABLE KEYS */;
/*!40000 ALTER TABLE `norma` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otdel`
--

DROP TABLE IF EXISTS `otdel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otdel` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `komplex_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6vws7yrr6ccv5kabhy5ysqhj4` (`komplex_id`),
  CONSTRAINT `FK6vws7yrr6ccv5kabhy5ysqhj4` FOREIGN KEY (`komplex_id`) REFERENCES `komplex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otdel`
--

LOCK TABLES `otdel` WRITE;
/*!40000 ALTER TABLE `otdel` DISABLE KEYS */;
/*!40000 ALTER TABLE `otdel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `id` bigint(20) NOT NULL,
  `post_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (15,'Ведущий инженер'),(16,'Ведущий специалист'),(17,'Главный инженер'),(18,'Главный специалист'),(19,'Дежурный оперативный'),(20,'Зам. начальника отделения'),(21,'Зам. начальника'),(22,'Инженер'),(23,'Инженер 1 категории'),(24,'Инженер 2 категории'),(25,'Инженер-программист'),(26,'Кладовщик'),(27,'Машинист электростанции передвижной'),(28,'Машинист электростанции передвижной 4 разряда'),(29,'Начальник группы'),(30,'Начальник группы КИС «Клён»'),(31,'Начальник отдела'),(32,'Начальник отдела ЭСИ'),(33,'Начальник отделения'),(34,'Начальник пункта'),(35,'Начальник склада'),(36,'Начальник станции'),(37,'Начальник Центра'),(38,'Подсобный рабочий'),(39,'Слесарь-сантехник'),(40,'Слесарь-сантехник 4 разряда'),(41,'Специалист'),(42,'Специалист 1 категории'),(43,'Специалист 2 категории'),(44,'Техник'),(45,'Техник 1 категории'),(46,'Техник 2 категории'),(47,'Уборщик производственных и служебных помещений'),(48,'Уборщик производственных помещений'),(49,'Электрогазосварщик'),(50,'Электрогазосварщик 3 разряда'),(51,'Электромонтер 4 разряда'),(52,'Электромонтер по ремонту и обслуживанию электрооборудования 4 разряда'),(53,'Электромонтёр по ремонту и обслуживанию ЭО');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pover_prib`
--

DROP TABLE IF EXISTS `pover_prib`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pover_prib` (
  `id` bigint(20) NOT NULL,
  `chto_izm` varchar(255) DEFAULT NULL,
  `data_fakt` date DEFAULT NULL,
  `data_plan` date DEFAULT NULL,
  `data_posl` date DEFAULT NULL,
  `diapazon` varchar(255) DEFAULT NULL,
  `naimen` varchar(255) DEFAULT NULL,
  `period_prov` varchar(255) DEFAULT NULL,
  `primech` varchar(255) DEFAULT NULL,
  `tip` varchar(255) DEFAULT NULL,
  `tochnost` varchar(255) DEFAULT NULL,
  `zav_nom` varchar(255) DEFAULT NULL,
  `stanciya_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjvle2p3ntjgydcg4iccil891h` (`stanciya_id`),
  CONSTRAINT `FKjvle2p3ntjgydcg4iccil891h` FOREIGN KEY (`stanciya_id`) REFERENCES `stanciya` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pover_prib`
--

LOCK TABLES `pover_prib` WRITE;
/*!40000 ALTER TABLE `pover_prib` DISABLE KEYS */;
/*!40000 ALTER TABLE `pover_prib` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rashodniki`
--

DROP TABLE IF EXISTS `rashodniki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rashodniki` (
  `id` bigint(20) NOT NULL,
  `ed_izm` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rashodniki`
--

LOCK TABLES `rashodniki` WRITE;
/*!40000 ALTER TABLE `rashodniki` DISABLE KEYS */;
/*!40000 ALTER TABLE `rashodniki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'ROLE_ADMIN'),(2,'ROLE_USER'),(3,'ROLE_G·E'),(4,'ROLE_IVTS'),(5,'ROLE_IP-1'),(6,'ROLE_IP-2'),(7,'ROLE_IP-3'),(8,'ROLE_IP-5'),(9,'ROLE_KOIPSIK'),(10,'ROLE_MTO'),(11,'ROLE_OT'),(12,'ROLE_OKHSOiEZS'),(13,'ROLE_Upravleniye'),(14,'ROLE_UTS'),(15,'ROLE_EMS');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rpr`
--

DROP TABLE IF EXISTS `rpr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rpr` (
  `id` bigint(20) NOT NULL,
  `data_ai` date DEFAULT NULL,
  `data_aur` date DEFAULT NULL,
  `data_son` date DEFAULT NULL,
  `neispr_h` varchar(255) DEFAULT NULL,
  `neispr_v` varchar(255) DEFAULT NULL,
  `nom_ai` varchar(255) DEFAULT NULL,
  `nom_aur` varchar(255) DEFAULT NULL,
  `nom_son` varchar(255) DEFAULT NULL,
  `nom_uved` varchar(255) DEFAULT NULL,
  `primechanie` varchar(255) DEFAULT NULL,
  `udovlet` bit(1) NOT NULL,
  `ustr_neispr` varchar(255) DEFAULT NULL,
  `zakl_kom` varchar(255) DEFAULT NULL,
  `zakrita` bit(1) NOT NULL,
  `stanciya_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKs8h518yviht0oq9of06qtodu` (`stanciya_id`),
  CONSTRAINT `FKs8h518yviht0oq9of06qtodu` FOREIGN KEY (`stanciya_id`) REFERENCES `stanciya` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rpr`
--

LOCK TABLES `rpr` WRITE;
/*!40000 ALTER TABLE `rpr` DISABLE KEYS */;
/*!40000 ALTER TABLE `rpr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `size_siz`
--

DROP TABLE IF EXISTS `size_siz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `size_siz` (
  `id` bigint(20) NOT NULL,
  `height` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `individual_protection_means_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3g35ul8r6e9afdt1c09y2rrht` (`individual_protection_means_id`),
  CONSTRAINT `FK3g35ul8r6e9afdt1c09y2rrht` FOREIGN KEY (`individual_protection_means_id`) REFERENCES `individual_protection_means` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `size_siz`
--

LOCK TABLES `size_siz` WRITE;
/*!40000 ALTER TABLE `size_siz` DISABLE KEYS */;
INSERT INTO `size_siz` VALUES (863,'3-4','40-42',690),(864,'5-6','40-42',690),(865,'7-8','40-42',690),(866,'1-2','44-46',690),(867,'3-4','44-46',690),(868,'5-6','44-46',690),(869,'7-8','44-46',690),(870,'1-2','48-50',690),(871,'3-4','48-50',690),(872,'5-6','48-50',690),(873,'7-8','48-50',690),(874,'1-2','52-54',690),(875,'3-4','52-54',690),(876,'5-6','52-54',690),(877,'7-8','52-54',690),(878,'1-2','56-58',690),(879,'3-4','56-58',690),(880,'5-6','56-58',690),(881,'7-8','56-58',690),(882,'1-2','60-62',690),(883,'3-4','60-62',690),(884,'5-6','60-62',690),(885,'7-8','60-62',690),(886,'1-2','40-42',692),(887,'3-4','40-42',692),(888,'5-6','40-42',692),(889,'7-8','40-42',692),(890,'1-2','44-46',692),(891,'3-4','44-46',692),(892,'5-6','44-46',692),(893,'7-8','44-46',692),(894,'1-2','48-50',692),(895,'3-4','48-50',692),(896,'5-6','48-50',692),(897,'7-8','48-50',692),(898,'1-2','52-54',692),(899,'3-4','52-54',692),(900,'5-6','52-54',692),(901,'7-8','52-54',692),(902,'1-2','56-58',692),(903,'3-4','56-58',692),(904,'5-6','56-58',692),(905,'7-8','56-58',692),(906,'1-2','60-62',692),(907,'3-4','60-62',692),(908,'5-6','60-62',692),(909,'7-8','60-62',692),(910,'','7.0',693),(911,'','7.5',693),(912,'','8.0',693),(913,'','8.5',693),(914,'','9.0',693),(915,'','9.5',693),(916,'','10.0',693),(917,'','10.5',693),(918,'','11.0',693),(919,'','11.5',693),(920,'','12.0',693),(921,'','35',694),(922,'','36',694),(923,'','37',694),(924,'','38',694),(925,'','39',694),(926,'','40',694),(927,'','41',694),(928,'','42',694),(929,'','43',694),(930,'','44',694),(931,'','45',694),(932,'','46',694),(933,'','47',694),(934,'','48',694),(935,'','49',694),(936,'','50',695),(937,'','51',695),(938,'','52',695),(939,'','53',695),(940,'','54',695),(941,'','55',695),(942,'','56',695),(943,'','57',695),(944,'','58',695),(945,'','59',695),(946,'','60',695),(947,'','61',695),(948,'','62',695),(949,'','63',695),(950,'','64',695),(951,'','65',695),(952,'','66',695),(953,'','35',696),(954,'','36',696),(955,'','37',696),(956,'','38',696),(957,'','39',696),(958,'','40',696),(959,'','41',696),(960,'','42',696),(961,'','43',696),(962,'','44',696),(963,'','45',696),(964,'','46',696),(965,'','47',696),(966,'','48',696),(967,'','49',696),(968,'','7.0',697),(969,'','7.5',697),(970,'','8.0',697),(971,'','8.5',697),(972,'','9.0',697),(973,'','9.5',697),(974,'','10.0',697),(975,'','10.5',697),(976,'','11.0',697),(977,'','11.5',697),(978,'','12.0',697),(1042,'1-2','40-42',690);
/*!40000 ALTER TABLE `size_siz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sost_chast`
--

DROP TABLE IF EXISTS `sost_chast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sost_chast` (
  `id` bigint(20) NOT NULL,
  `naimen` varchar(255) DEFAULT NULL,
  `zav_nom` varchar(255) DEFAULT NULL,
  `stanciya_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqmwpjkgk6dkfnslp46em0hatm` (`stanciya_id`),
  CONSTRAINT `FKqmwpjkgk6dkfnslp46em0hatm` FOREIGN KEY (`stanciya_id`) REFERENCES `stanciya` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sost_chast`
--

LOCK TABLES `sost_chast` WRITE;
/*!40000 ALTER TABLE `sost_chast` DISABLE KEYS */;
/*!40000 ALTER TABLE `sost_chast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sredstvo`
--

DROP TABLE IF EXISTS `sredstvo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sredstvo` (
  `id` bigint(20) NOT NULL,
  `indeks` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sredstvo`
--

LOCK TABLES `sredstvo` WRITE;
/*!40000 ALTER TABLE `sredstvo` DISABLE KEYS */;
/*!40000 ALTER TABLE `sredstvo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stanciya`
--

DROP TABLE IF EXISTS `stanciya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stanciya` (
  `id` bigint(20) NOT NULL,
  `data_izg` date DEFAULT NULL,
  `data_pod_n` date DEFAULT NULL,
  `data_sled_n` date DEFAULT NULL,
  `data_vvoda` date DEFAULT NULL,
  `doljn` varchar(255) DEFAULT NULL,
  `ed` varchar(255) DEFAULT NULL,
  `fio_otv` varchar(255) DEFAULT NULL,
  `garant_res` varchar(255) DEFAULT NULL,
  `garant_srok` varchar(255) DEFAULT NULL,
  `kompl` varchar(255) DEFAULT NULL,
  `mesto_rasp` varchar(255) DEFAULT NULL,
  `modern` varchar(255) DEFAULT NULL,
  `narabotka` double NOT NULL,
  `org_izg` varchar(255) DEFAULT NULL,
  `org_razr` varchar(255) DEFAULT NULL,
  `primech` varchar(255) DEFAULT NULL,
  `rab_tz` varchar(255) DEFAULT NULL,
  `srok_sluj` varchar(255) DEFAULT NULL,
  `srok_sluzhb_snach` varchar(255) DEFAULT NULL,
  `to_stor_o` varchar(255) DEFAULT NULL,
  `to_sv_s` varchar(255) DEFAULT NULL,
  `uchet` varchar(255) DEFAULT NULL,
  `zav_nom` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `otdel_id` bigint(20) DEFAULT NULL,
  `sredstvo_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtni8ltxshjupff9ospuvwtyxc` (`otdel_id`),
  KEY `FK2dkgfx231vn07bd85iwm5j7g5` (`sredstvo_id`),
  CONSTRAINT `FK2dkgfx231vn07bd85iwm5j7g5` FOREIGN KEY (`sredstvo_id`) REFERENCES `sredstvo` (`id`),
  CONSTRAINT `FKtni8ltxshjupff9ospuvwtyxc` FOREIGN KEY (`otdel_id`) REFERENCES `otdel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stanciya`
--

LOCK TABLES `stanciya` WRITE;
/*!40000 ALTER TABLE `stanciya` DISABLE KEYS */;
/*!40000 ALTER TABLE `stanciya` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'$2a$10$WUI/ga/mwaEddKp5nfiH7.qBCDsQdlzis.9IGIquJoCYJ1Itvl9iW','admin'),(2,'$2a$10$S6kntxSMnN5mW5m47v0/herYk.i2iI4HgUXWHiRU6M7ofTEmvxi7G','user'),(3,'$2a$10$gWPtVom81a/gpyLY6wZr4e1v2DcFReqB19UvSzIgr24awy2i5xhOS','ivc'),(4,'$2a$10$X.OzBn97IgqcjHfzl1X9ieE8xsh7e08i4o3sGBd1VtEFLsiQpkroW','user111');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `user_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`roles_id`),
  KEY `FKj9553ass9uctjrmh0gkqsmv0d` (`roles_id`),
  CONSTRAINT `FK55itppkw3i07do3h7qoclqd4k` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKj9553ass9uctjrmh0gkqsmv0d` FOREIGN KEY (`roles_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1),(2,2),(3,4),(4,5);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `write_off_act`
--

DROP TABLE IF EXISTS `write_off_act`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `write_off_act` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_act` datetime(6) DEFAULT NULL,
  `komplex` varchar(255) DEFAULT NULL,
  `name_act` varchar(255) DEFAULT NULL,
  `num_write_off` double NOT NULL,
  `item_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9vawwgbq3kb3j8f3c4fl9sp9k` (`item_id`),
  CONSTRAINT `FK9vawwgbq3kb3j8f3c4fl9sp9k` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `write_off_act`
--

LOCK TABLES `write_off_act` WRITE;
/*!40000 ALTER TABLE `write_off_act` DISABLE KEYS */;
/*!40000 ALTER TABLE `write_off_act` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-10 12:00:02
